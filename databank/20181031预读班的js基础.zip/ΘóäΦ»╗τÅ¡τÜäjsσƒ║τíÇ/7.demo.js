var length = 10;

function fn() {
    console.log(this.length);
}
var yideng = {
    length: 5,
    method: function (fn) {
        //fn();
        arguments[0]();
    }
};
yideng.method(fn, 1);