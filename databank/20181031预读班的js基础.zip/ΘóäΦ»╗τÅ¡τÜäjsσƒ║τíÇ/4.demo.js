        function test(m) {
            //函数的参数的m  是按值传递的
            //m的值是指到一起的 
            m.v = 5;
        }
        var m = {
            k: 30
        };
        test(m);
        alert(m.v);
        // var a = 1;
        // var b = a;
        // b = 2;
        // alert(a);

        // //按址
        // var a = {
        //     name: "laoyuan"
        // };
        // var b = a;
        // b.name = "yideng";
        // console.log(a.name);
        // Object.prototype.name = "zhijia";
        // 1.0.name 
        // 1.name
        // Function.name

        // var a = {age:10};
        // var b = a;
        // b= {age:30};
        // console.log(a);