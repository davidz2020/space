function a() {
    alert(10)
}
var a;
alert(a); //==> //函数体
a(); //=》执行这个函数
a = 3;
alert(a); //=> a=3
a = 6;
a(); //a不是一个函数

//1.=======基本提升=====
// test();
// function test(){}
// test();

// if(false){
//     var a  = 1;
// }
// alert(a);
//2.======函数优先级别比变量高=======
//3.词法作用域名当函数名和变量 忽略变量名