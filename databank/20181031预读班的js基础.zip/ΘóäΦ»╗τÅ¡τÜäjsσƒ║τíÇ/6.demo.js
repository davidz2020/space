//10 -  9 (95/10) = 1

if (speed>0 && spedd<100) {
    
}else if(speed>100 && spedd<300){

}else if(){

}


switch (key) {
    case value:
        
        break;

    default:
        break;
}