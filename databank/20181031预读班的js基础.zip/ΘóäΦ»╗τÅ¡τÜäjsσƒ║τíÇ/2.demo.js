        // this.a = 20;
        // var test = {
        //     a: 40,
        //     init:()=>{
        //         // function yideng(){
        //         //     alert(this.a);
        //         // }
        //         // yideng()
        //         alert(this.a);
        //     }
        // };
        // test.init();
        function Car() {
            this.color = "red";
        }
        Car.prototype.color = "yellow";
        (new Car()).color = "red";
        //1.谁调用函数 this就指向谁
        //2.init没宿主环境 window
        //3.=> 绑定她爹的运行环境
        //4.在类上的this 先绑定构造函数里的this