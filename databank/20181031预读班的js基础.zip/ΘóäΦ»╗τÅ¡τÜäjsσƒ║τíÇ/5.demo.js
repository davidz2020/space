function yideng() {
    console.log(1);
}
(function () {
    if (false) {
        function yideng() {
            console.log(2);
        }
    }
    yideng();
})();
// function yideng() {
//     console.log(1);
// }
// if (true) {
//     const yideng = () => {
//         console.log(2);
//     }
// } else {
//     function yideng() {
//         console.log(3);
//     }
// }
// yideng();
