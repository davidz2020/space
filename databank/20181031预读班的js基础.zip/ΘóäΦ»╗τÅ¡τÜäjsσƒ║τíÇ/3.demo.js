var list_li = document.getElementsByTagName("li");
        for (let i = 0; i < list_li.length; i++) {
            // (function (i) {
            list_li[i].onclick = function () {
                console.log(this.innerText);
            }
            //})(i)
        }
        // var tmp = 123;
        // {
        //     tmp = "yideng";
        //     let tmp;
        // }

        // let a = 1;
        // try{
        //     throw 1;
        // }catch(a){
        //     console.log(a);
        // }

        // (function (){
        //     var a = 1;
        // })();

        // {
        //     let a = 1;
        // }
        // console.log(a);