//npm install karma-jasmine jasmine-core --save-dev
//核心的库jasmine-core  适配器 karma-jasmine
describe("测试基本函数的API",function(){
    it("+1函数的应用",function(){
        expect(window.add(1)).toBe(1);
        expect(window.add(2)).toBe(3);
    });
});